# code and all graphics for noncommercial use only 

from operator import truediv
import random  
import time
import sys
from timeit import repeat
from tkinter import FALSE
from turtle import delay
import pygame 
from pygame.locals import * 
import math

# alle Bilder laden 
santa = pygame.image.load('./Santa.png')
bild1 = pygame.image.load('./Schornstein1.png')
bild2 = pygame.image.load('./Schornstein2.png')
bild3 = pygame.image.load('./Schornstein3.png')

# Liste, in der dann die einzelnen Pipes gespeichert werden 
pipes = []

# liste der Bilder und der Höhen der Pipes
pipeimage = [bild1,bild2,bild3]
hights = [100,150,200,250,300,350]

# alle Variablen und Funktionen des Spiels werden Festgelegt
class Game:
  framenumber = 1
  flap = False
  gameover = False
  level = 0
  pSpeed = 1
  pSpawn = 1
  difficulty = 1
  score = 1
  wait = False

  # Spawn- und Bewegungsgeschwidnigkeit wird bei einem Levelup erhöht
  def levelUp(self):
    self.level += 1
    self.difficulty = (((-60) * (math.e ** (-0.07 * self.level))) + 60)
    self.pSpeed += (self.difficulty // 1) * 0.05
    self.pSpawn = 60 - ((self.difficulty // 10) * 10) 

  # funtion wird beim Rundenende aufgerufen, alle Pipes werden gelöscht
  def fgameover(self,pipes):
    for i in pipes:
      del i
    game.gameover = True

# Spiel wird initialisiert und das erste level beginnt
game = Game()
game.levelUp()

# Klasse der Pipes
class Pipe:
  # Höhe und Bild wird festgelegt
  def __init__(self,pipeimage,hights):
    self.hight = random.choice(hights)
    self.image = random.choice(pipeimage)
    self.topImage = pygame.transform.scale(self.image,(120,self.hight))
    self.bottomImage = pygame.transform.scale(self.image,(120,400 - self.hight))
    self.bottomImage = pygame.transform.rotate(self.bottomImage, 180)
    self.position = 1400

  # die Bewegung der Pipes
  def pMove(self,pSpeed):
      self.position -= 10 + pSpeed

  def __del__(self):
    self.position = 0

# Funtion um zu überprüfen, ob Santa auf Höhe der Pipes ist und das Spiel beendet wird
def checkgameover(position,positiony,hight):
  if (position > 100) and (position < 230):
    if ((positiony + 15) < (400 - hight)) or ((positiony + 75 ) > (700 - hight)):
      game.fgameover(pipes)

# Funtion um Score und Level anzuzeigen
def showStats(screen,x,y):
    font = pygame.font.SysFont("monospace", 35)
    game.score = str(game.framenumber)
    scoretext = font.render("Score = "+game.score, 1, (250,250,250))
    screen.blit(scoretext, (x,y))
    leveltext = font.render("Level = "+str(game.level), 1, (250,250,250))
    screen.blit(leveltext, (x,y + 40))

nObject = Pipe(pipeimage,hights)
pipes.append(nObject)
def update(dt,positiony,gravity,steigen,game):
  game.flap = False

  # Aktionen die durch das Drücken einer Taste ausgelöst werden 
  for event in pygame.event.get():
    if event.type == QUIT:
      pygame.quit() 
      sys.exit() 
    if event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP):
      if game.gameover == False: 
        game.flap = True
      if (game.wait == False) and (game.gameover == True):
        time.sleep(1)
        game.wait = True
      else:
        if game.gameover == True:
          game.gameover = False
          positiony = 275
          gravity = 1
          steigen = 0
          game.pSpeed = 1
          game.framenumber = 0
          game.wait = False
          game.level = 0
          game.levelUp()
          nObject = Pipe(pipeimage,hights)
          pipes.append(nObject)

  positiony += gravity - steigen
  return positiony
 
# Gegenstände/Graphiken werden "gezeichnet"
def draw(screen, positiony,game):

  screen.fill((6,10,6))
  background = pygame.image.load('./Hintergrund.jpg')
  gOver = pygame.image.load('./GameOver.png')
  bBook = pygame.image.load('./BurningBook.png')      

  if game.gameover != True:    
    background = pygame.transform.scale(background,(1400, 700))
    screen.blit(background,(0,0))
    game.framenumber += 1

    #pipes zeichen
    for i in pipes:
      screen.blit(i.topImage,(i.position,700 - i.hight))
      screen.blit(i.bottomImage,(i.position,0))
      i.pMove(game.pSpeed)
      if i.position < (-120):
        del i
    
    screen.blit(santa,(175,positiony + 20))

    # alle 20 frames kommt ein level up
    if (game.framenumber % 200) == 0:
      game.levelUp()

    # abhägnig von dem Level werden Pipes gespawnt
    if (game.framenumber % game.pSpawn) == 0:
      nPipe = Pipe(pipeimage,hights)
      pipes.append(nPipe)

    showStats(screen,5,5)

    for i in pipes:
      checkgameover(i.position,positiony,i.hight)
    if ((positiony + 160 ) > (700)) or ((positiony + 68) < (0)):
      game.fgameover(pipes)

  else:   
    # Anzeige nach einer Runde 
    bBook = pygame.transform.scale(bBook,(700, 700))
    screen.blit(bBook,(500,0))
    screen.blit(gOver,(40,150))
    showStats(screen,20,600)
    for i in pipes:
      pipes.remove(i)
      del i
  
  # Flip the display so that the things we drew actually show up.
  pygame.display.flip()

def runPyGame():
  # Initialise PyGame. Set Caption of the Window
  pygame.init()
  pygame.display.set_caption("Flappy Santa")
  
  # Set up the clock. This will tick every frame and thus maintain a relatively constant framerate. Hopefully.
  fps = 60.0
  fpsClock = pygame.time.Clock()
  positiony = 100
  gravity = 1
  steigen = 0
  game.flap = False

  # Set up the window.
  width, height = 1400, 700 
  screen = pygame.display.set_mode((width, height))

  # Main game loop.
  dt = 1/fps # dt is the time since last frame.
  while True: # Loop forever!
    positiony = update(dt,positiony,gravity,steigen,game)
    gravity = gravity + 0.2*gravity
    steigen = steigen*0.7
    draw(screen,positiony,game)
    if game.flap == True:
      gravity = 1
      steigen = 45
    if game.gameover == True:
      gravity = 1
      steigen = 0
    dt = fpsClock.tick(fps)

runPyGame()